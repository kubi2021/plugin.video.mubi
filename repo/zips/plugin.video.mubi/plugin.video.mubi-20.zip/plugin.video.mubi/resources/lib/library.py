from pathlib import Path
import sys
import xbmc
import xbmcgui
import xbmcaddon
from .film import Film
from typing import List, Optional, Tuple
import os
import shutil
from typing import Set
import re

class Library:
    def __init__(self):
        self.films = {}  # Dictionary mapping mubi_id to Film object

    def add_film(self, film: Film):
        if not film or not film.mubi_id or not film.title or not film.metadata:
            raise ValueError("Invalid film: missing required fields (mubi_id, title, or metadata).")
        
        if film.mubi_id in self.films:
            # Film exists, merge availability data
            existing_film = self.films[film.mubi_id]
            if film.available_countries:
                existing_film.available_countries.update(film.available_countries)
        else:
            # New film, add to library
            self.films[film.mubi_id] = film

    def __len__(self):
        return len(self.films)

    def sync_locally(self, base_url: str, plugin_userdata_path: Path, skip_external_metadata: bool = False):
        """
        Synchronize the local library with fetched film data from MUBI.

        :param base_url: The base URL for creating STRM files.
        :param plugin_userdata_path: The path where film folders are stored.
        :param skip_external_metadata: If True, skip attempting to fetch external metadata (IMDB/TMDB) for new films.
        """
        # Films are expected to be already filtered by the time they are added to Library

        # Log films that contain problematic characters for debugging
        for film in self.films.values():
            if '#' in film.title or any(char in film.title for char in '<>:"/\\|?*^%$&{}@!;`~'):
                xbmc.log(
                    f"Processing film with special characters: '{film.title}' "
                    f"-> sanitized: '{film.get_sanitized_folder_name()}'",
                    xbmc.LOGINFO
                )

        # Initialize counters
        newly_added = 0
        failed_to_add = 0
        availability_updated = 0
        films_to_process = len(self.films)

        # Initialize progress dialog
        pDialog = xbmcgui.DialogProgress()
        pDialog.create("Syncing with MUBI 2/2", f"Processing {films_to_process} films...")

        import concurrent.futures

        # Get concurrency setting (default to 5 for safety on low-end devices)
        # 1 = Serial, 5 = Standard, 10+ = High Performance
        try:
             import xbmcaddon
             max_workers = xbmcaddon.Addon().getSettingInt("sync_concurrency")
             
             if max_workers == 0:
                 # Auto mode: 90% of threads
                 cpu_count = os.cpu_count() or 1
                 max_workers = max(1, int(cpu_count * 0.9))
                 xbmc.log(f"MUBI Sync: Auto-concurrency detected {cpu_count} CPUs. Using {max_workers} threads (90%).", xbmc.LOGINFO)
             elif max_workers < 1:
                 # Fallback for invalid negative values
                 max_workers = 5
        except Exception:
             max_workers = 5
             
        xbmc.log(f"Starting sync with {max_workers} worker threads.", xbmc.LOGDEBUG)
        
        processed_count = 0

        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                # Submit all tasks
                future_to_film = {
                    executor.submit(self.prepare_files_for_film, film, base_url, plugin_userdata_path, skip_external_metadata): film
                    for film in self.films.values()
                    if self.is_film_valid(film)
                }

                # Process results as they complete
                for future in concurrent.futures.as_completed(future_to_film):
                    # Check cancel
                    if pDialog.iscanceled():
                        xbmc.log("User canceled the sync process.", xbmc.LOGDEBUG)
                        # cancel_futures was added in Python 3.9
                        if sys.version_info >= (3, 9):
                            executor.shutdown(wait=False, cancel_futures=True)
                        else:
                            executor.shutdown(wait=False)
                        break

                    film = future_to_film[future]
                    processed_count += 1
                    
                    # Update progress
                    percent = int((processed_count / films_to_process) * 100)
                    progress_msg = f"Processing movie {processed_count} of {films_to_process}:\n{film.title}"
                    pDialog.update(percent, progress_msg)

                    try:
                        result = future.result()
                        if result is True:
                            newly_added += 1
                        elif result is False:
                            failed_to_add += 1
                        elif result is None:
                            availability_updated += 1
                    except Exception as e:
                        xbmc.log(f"Unhandled exception processing film '{film.title}': {e}", xbmc.LOGERROR)
                        failed_to_add += 1

            # Final cleanup of obsolete files
            obsolete_films_count = self.remove_obsolete_files(plugin_userdata_path)

            # Construct summary message
            message = (
                f"Sync completed successfully!\n"
                f"New movies added: {newly_added}\n"
                f"Failed to add: {failed_to_add}\n"
                f"Obsolete movies removed: {obsolete_films_count}"
            )
            
            # Log results
            xbmc.log(
                f"Sync completed. New films: {newly_added}, Failed films: {failed_to_add}, "
                f"Obsolete films removed: {obsolete_films_count}",
                xbmc.LOGDEBUG
            )
            
            # Show summary dialog
            xbmcgui.Dialog().ok("MUBI", message)
        finally:
            # Ensure the dialog is closed in the end
            pDialog.close()



    def is_film_valid(self, film: Film) -> bool:
        # Check that film has all necessary attributes AND at least one available country
        if not film.mubi_id or not film.title or not film.metadata:
            return False
            
        # Check integrity of available_countries
        # Case 1: Empty dictionary (True Zombie) - Caught by 'and film.available_countries'
        # Case 2: Keys with empty values (Semi-Zombie) - e.g. {'DK': {}} due to null consumable
        if not film.available_countries:
            return False
            
        # Ensure at least one country has valid consumable data (truthy value)
        has_valid_country = any(data for data in film.available_countries.values() if data)
        return has_valid_country

    def prepare_files_for_film(
        self, film: Film, base_url: str, plugin_userdata_path: Path, skip_external_metadata: bool = False
    ) -> Optional[bool]:
        """
        Prepare the necessary files for a given film. Creates NFO and STRM files.
        The NFO file country availability is always updated on each sync.
        Full NFO creation is only done if NFO doesn't exist (expensive due to OMDB API calls).

        :param film: The Film object to process.
        :param base_url: The base URL for the STRM file.
        :param plugin_userdata_path: The path where film folders are stored.
        :param skip_external_metadata: If True, do not attempt to fetch external metadata.
        :return:
            - True if files were created/updated successfully.
            - False if file creation failed.
            - None if NFO already exists and only availability was updated.
        """
        film_folder_name = film.get_sanitized_folder_name()
        film_path = plugin_userdata_path / film_folder_name

        # Define file paths
        strm_file = film_path / f"{film_folder_name}.strm"
        nfo_file = film_path / f"{film_folder_name}.nfo"

        try:
            # Check if NFO already exists (skip expensive NFO creation but always update availability)
            nfo_exists = nfo_file.exists()
            if nfo_exists:
                # Update country availability in NFO file (quick operation)
                xbmc.log(f"Updating availability for '{film.title}' (NFO exists).", xbmc.LOGDEBUG)
                film.update_nfo_availability(nfo_file)
                return None  # Indicate availability was updated (not a new film)
        except PermissionError as e:
            xbmc.log(f"PermissionError when accessing files for film '{film.title}': {e}", xbmc.LOGERROR)
            return False  # Indicate failure due to permission error

        try:
            # Create the movie folder if it doesn't exist
            film_path.mkdir(parents=True, exist_ok=True)
            xbmc.log(f"Created folder '{film_path}'.", xbmc.LOGDEBUG)

            # Attempt to create the NFO file first
            xbmc.log(f"Creating NFO file for film '{film.title}'.", xbmc.LOGDEBUG)
            film.create_nfo_file(film_path, base_url, skip_external_metadata=skip_external_metadata)

            # Verify if the NFO file was created successfully
            if not nfo_file.exists():
                xbmc.log(
                    f"Skipping creation of STRM file for '{film.title}' as NFO file was not created.",
                    xbmc.LOGWARNING
                )
                # Remove the movie folder since NFO creation failed
                shutil.rmtree(film_path)
                xbmc.log(f"Removed folder '{film_path}' due to failed NFO creation.", xbmc.LOGDEBUG)
                return False  # Indicate failure in file creation

            # If NFO was created successfully, proceed to create the STRM file
            xbmc.log(f"Creating STRM file for film '{film.title}'.", xbmc.LOGDEBUG)
            film.create_strm_file(film_path, base_url)

            # BUG #9 FIX: Verify that the STRM file was actually created
            if not strm_file.exists():
                xbmc.log(
                    f"STRM file creation failed for '{film.title}' - file does not exist after creation.",
                    xbmc.LOGERROR
                )
                # Remove the movie folder since STRM creation failed
                shutil.rmtree(film_path)
                xbmc.log(f"Removed folder '{film_path}' due to failed STRM creation.", xbmc.LOGDEBUG)
                return False  # Indicate failure in file creation

            xbmc.log(f"Successfully created STRM file for '{film.title}'.", xbmc.LOGDEBUG)
            return True  # Indicate successful creation of both files

        except Exception as e:
            # Handle unexpected exceptions during file operations
            xbmc.log(f"Error processing film '{film.title}': {e}", xbmc.LOGERROR)
            # Attempt to remove the folder if it exists to maintain consistency
            if film_path.exists():
                shutil.rmtree(film_path)
                xbmc.log(f"Removed folder '{film_path}' due to error.", xbmc.LOGDEBUG)
            return False  # Indicate failure due to exception




    def remove_obsolete_files(self, plugin_userdata_path: Path) -> int:
        """
        Remove folders in plugin_userdata_path that do not correspond to any film in the library.
        
        :param plugin_userdata_path: Path where the film folders are stored.
        :return: The number of obsolete film folders removed.
        """
        # Get a set of sanitized folder names for the current films in the library
        current_film_folders = {film.get_sanitized_folder_name() for film in self.films.values()}

        # Track obsolete folder count
        obsolete_folders_count = 0

        # Loop through each directory in plugin_userdata_path
        for folder in plugin_userdata_path.iterdir():
            if folder.is_dir() and folder.name not in current_film_folders:
                # Remove the folder if it's not in the current films
                shutil.rmtree(folder)
                obsolete_folders_count += 1

        return obsolete_folders_count

