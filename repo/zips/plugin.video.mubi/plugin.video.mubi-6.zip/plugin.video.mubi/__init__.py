# This file makes the plugin_video_mubi directory a Python package
